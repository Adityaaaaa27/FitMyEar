# FitMyEar - Custom Ear Piece Fitting App

## Overview
FitMyEar is a medical-tech mobile application for creating custom-fit ear pieces through ear photo capture and 3D reconstruction. Built with React Native (Expo) using the FitMyEar branded color palette.

## Project Status
MVP Complete - Core features implemented:
- Splash screen with animated logo
- Email/password authentication (Sign In/Sign Up)
- Dashboard with navigation cards
- Camera capture with ear alignment guide
- Photo gallery and upload functionality
- 3D reconstruction status tracking
- Settings with sign out and data management

## Architecture

### Tech Stack
- **Framework**: React Native with Expo SDK 54
- **Navigation**: React Navigation 7 (Stack-based)
- **UI**: Custom components following iOS 26 Liquid Glass design principles
- **Storage**: AsyncStorage for local persistence
- **Camera**: expo-camera for photo capture
- **Image Picker**: expo-image-picker for gallery access

### Project Structure
```
├── App.tsx                    # Root component with providers
├── navigation/
│   ├── AuthNavigator.tsx      # Sign In/Sign Up stack
│   └── MainNavigator.tsx      # Main app stack (Dashboard, Camera, etc.)
├── screens/
│   ├── SplashScreen.tsx       # Animated splash with logo
│   ├── SignInScreen.tsx       # Email/password sign in
│   ├── SignUpScreen.tsx       # Account creation
│   ├── DashboardScreen.tsx    # Main hub with feature cards
│   ├── CameraCaptureScreen.tsx # Camera with ear guide overlay
│   ├── UploadScreen.tsx       # Photo review and upload
│   ├── ReconstructionStatusScreen.tsx # Processing status
│   └── SettingsScreen.tsx     # Profile and app settings
├── components/
│   ├── Button.tsx             # Primary button with animation
│   ├── Card.tsx               # Elevated card component
│   ├── HeaderTitle.tsx        # Custom header with logo
│   ├── ErrorBoundary.tsx      # Error handling wrapper
│   └── Screen*.tsx            # Screen wrapper components
├── hooks/
│   ├── useAuth.tsx            # Authentication context
│   ├── useTheme.ts            # Theme context
│   └── useScreenInsets.ts     # Safe area calculations
├── utils/
│   └── storage.ts             # AsyncStorage utilities
└── constants/
    └── theme.ts               # Design tokens and colors
```

### Color Palette (FitMyEar Brand)
- Primary Blue: `#1A5CFF`
- Highlight Yellow: `#FFD93D`
- White: `#FFFFFF`
- Dark Text: `#0A0A0A`
- Light Background: `#F7F7F8`

## Development

### Running the App
```bash
npm run dev
```

### Key Features
1. **Authentication**: Local storage-based auth with email/password
2. **Camera Capture**: Native camera with ear alignment overlay
3. **Photo Management**: Capture, preview, delete photos
4. **Upload Flow**: Simulated upload with progress indicator
5. **Status Tracking**: Visual progress steps for reconstruction

## User Preferences
- Clean, minimal medical-tech aesthetic
- No emojis in the UI
- Modern animations (spring-based)
- Consistent spacing and typography
