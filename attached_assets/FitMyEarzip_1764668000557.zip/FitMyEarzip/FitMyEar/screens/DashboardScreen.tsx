import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ScreenScrollView } from "@/components/ScreenScrollView";
import { ThemedText } from "@/components/ThemedText";
import { BrandColors, Spacing, BorderRadius } from "@/constants/theme";
import { MainStackParamList } from "@/navigation/MainNavigator";
import { useAuth } from "@/hooks/useAuth";

type DashboardScreenProps = {
  navigation: NativeStackNavigationProp<MainStackParamList, "Dashboard">;
};

interface DashboardCardProps {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
  onPress: () => void;
}

function DashboardCard({
  icon,
  title,
  description,
  onPress,
}: DashboardCardProps) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 150 });
  };

  const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

  return (
    <AnimatedPressable
      style={[styles.card, animatedStyle]}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <View style={styles.cardAccent} />
      <View style={styles.cardContent}>
        <View style={styles.cardIcon}>
          <Feather name={icon} size={28} color={BrandColors.primaryBlue} />
        </View>
        <View style={styles.cardText}>
          <ThemedText type="h4" style={styles.cardTitle}>
            {title}
          </ThemedText>
          <ThemedText type="small" style={styles.cardDescription}>
            {description}
          </ThemedText>
        </View>
        <Feather name="chevron-right" size={24} color="#CCC" />
      </View>
    </AnimatedPressable>
  );
}

export default function DashboardScreen({ navigation }: DashboardScreenProps) {
  const { user, isAdmin } = useAuth();

  return (
    <ScreenScrollView contentContainerStyle={styles.scrollContent}>
      <View style={styles.welcomeSection}>
        <ThemedText type="h2" style={styles.welcomeTitle}>
          Welcome{user?.name ? `, ${user.name}` : ""}
        </ThemedText>
        <ThemedText type="body" style={styles.welcomeText}>
          Create your custom-fit ear pieces in 3 simple steps
        </ThemedText>
      </View>

      <View style={styles.cardsContainer}>
        <DashboardCard
          icon="camera"
          title="Capture Ear Photos"
          description="Take photos of your ear using the guided camera"
          onPress={() => navigation.navigate("CameraCapture")}
        />

        <DashboardCard
          icon="upload-cloud"
          title="Upload Images"
          description="Review and upload your captured ear photos"
          onPress={() => navigation.navigate("Upload")}
        />

        <DashboardCard
          icon="activity"
          title="3D Reconstruction Status"
          description="Track your ear model processing progress"
          onPress={() => navigation.navigate("ReconstructionStatus")}
        />

        <DashboardCard
          icon="shopping-bag"
          title="My Orders"
          description="View and track your custom ear piece orders"
          onPress={() => navigation.navigate("OrderHistory")}
        />

        {isAdmin && (
          <DashboardCard
            icon="bar-chart-2"
            title="Admin Dashboard"
            description="View system statistics and manage orders"
            onPress={() => navigation.navigate("AdminDashboard")}
          />
        )}
      </View>

      <Pressable
        style={({ pressed }) => [
          styles.settingsButton,
          pressed && styles.settingsButtonPressed,
        ]}
        onPress={() => navigation.navigate("Settings")}
      >
        <Feather name="settings" size={20} color={BrandColors.darkText} />
        <ThemedText type="body" style={styles.settingsButtonText}>
          Settings
        </ThemedText>
      </Pressable>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingTop: Spacing["3xl"],
  },
  welcomeSection: {
    marginBottom: Spacing["2xl"],
  },
  welcomeTitle: {
    color: BrandColors.darkText,
    marginBottom: Spacing.sm,
  },
  welcomeText: {
    color: "#666",
  },
  cardsContainer: {
    gap: Spacing.lg,
  },
  card: {
    backgroundColor: BrandColors.white,
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(0, 0, 0, 0.05)",
  },
  cardAccent: {
    height: 4,
    backgroundColor: BrandColors.highlightYellow,
  },
  cardContent: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.xl,
  },
  cardIcon: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.md,
    backgroundColor: BrandColors.lightBackground,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.lg,
  },
  cardText: {
    flex: 1,
  },
  cardTitle: {
    color: BrandColors.darkText,
    marginBottom: Spacing.xs,
  },
  cardDescription: {
    color: "#666",
  },
  settingsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: Spacing["3xl"],
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
  },
  settingsButtonPressed: {
    opacity: 0.7,
  },
  settingsButtonText: {
    color: BrandColors.darkText,
  },
});
